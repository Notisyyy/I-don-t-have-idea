from flask import Flask, redirect, request, session, jsonify, render_template
import requests
import os
import json

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "changeme")

# Discord OAuth2 config
CLIENT_ID = "YOUR_DISCORD_CLIENT_ID"
CLIENT_SECRET = "YOUR_DISCORD_CLIENT_SECRET"
REDIRECT_URI = "http://localhost:5000/callback"
API_BASE_URL = "https://discord.com/api"

@app.route("/")
def index():
    user = session.get("user")
    return render_template("index.html", user=user)

@app.route("/login")
def login():
    return redirect(
        f"{API_BASE_URL}/oauth2/authorize?client_id={CLIENT_ID}&redirect_uri={REDIRECT_URI}&response_type=code&scope=identify"
    )

@app.route("/callback")
def callback():
    code = request.args.get("code")
    if not code:
        return "No code provided", 400

    data = {
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": REDIRECT_URI,
        "scope": "identify"
    }

    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    res = requests.post(f"{API_BASE_URL}/oauth2/token", data=data, headers=headers)
    res.raise_for_status()
    token = res.json().get("access_token")

    user_res = requests.get(f"{API_BASE_URL}/users/@me", headers={"Authorization": f"Bearer {token}"})
    user_res.raise_for_status()
    user = user_res.json()

    session["user"] = {
        "id": user["id"],
        "username": f"{user['username']}#{user['discriminator']}",
        "avatar": f"https://cdn.discordapp.com/avatars/{user['id']}/{user['avatar']}.png"
    }
    return redirect("/")

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")

@app.route("/api/scripts")
def get_scripts():
    with open("scripts.json") as f:
        scripts = json.load(f)
    return jsonify(scripts)

if __name__ == "__main__":
    app.run(debug=True)